import { NextResponse } from 'next/server';
import { XMLParser } from 'fast-xml-parser';

export const runtime = 'nodejs';

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  removeNSPrefix: true,
});

// c = cuenta código, según forma/método de pago
// Catálogo SAT c_FormaPago — clasificación para efectos de la póliza
const FORMAS_A_BANCOS = ['02', '03', '04', '05', '06', '28', '29', '31'];
const FORMAS_REVISION_MANUAL = ['12', '13', '15', '17', '23', '24', '25', '26', '27'];

function determinarCuentaAbono(metodoPago, formaPago) {
  if (metodoPago === 'PPD') {
    // PPD casi siempre usa forma 99 (Por definir) — la deuda queda como pasivo
    return { codigo: '2101', nombre: 'Proveedores de alimentos y bebidas', aviso: null };
  }
  // PUE
  if (formaPago === '01') {
    return { codigo: '1101', nombre: 'Caja', aviso: null };
  }
  if (FORMAS_A_BANCOS.includes(formaPago)) {
    return { codigo: '1102', nombre: 'Bancos', aviso: null };
  }
  if (formaPago === '30') {
    return {
      codigo: '1105',
      nombre: 'Anticipo a proveedores',
      aviso: 'Forma de pago "Aplicación de anticipos": se asumió que consume un anticipo ya registrado.',
    };
  }
  if (FORMAS_REVISION_MANUAL.includes(formaPago)) {
    return {
      codigo: '',
      nombre: '',
      aviso: `Forma de pago "${formaPago}" es un caso especial (dación en pago, compensación, condonación, etc.). No se asumió cuenta — selecciónala manualmente.`,
    };
  }
  // 08 Vales de despensa, 14 Pago por consignación, u otra no contemplada
  return {
    codigo: '1102',
    nombre: 'Bancos',
    aviso: `Forma de pago "${formaPago}" no tiene regla automática (se asumió Bancos). Revisa esta póliza.`,
  };
}

function redondear(numero) {
  return Math.round((numero + Number.EPSILON) * 100) / 100;
}

function comoArreglo(valor) {
  if (valor === undefined || valor === null) return [];
  return Array.isArray(valor) ? valor : [valor];
}

function procesarXml(nombreArchivo, xmlTexto) {
  try {
    const obj = parser.parse(xmlTexto);
    const comp = obj.Comprobante;
    if (!comp) {
      return { nombreArchivo, error: 'No se encontró el nodo Comprobante. ¿Es un CFDI válido?' };
    }

    const total = parseFloat(comp['@_Total']);
    const subtotal = parseFloat(comp['@_SubTotal']);
    const metodoPago = comp['@_MetodoPago'] || 'PUE';
    const formaPago = comp['@_FormaPago'] || '99';
    const fecha = (comp['@_Fecha'] || '').slice(0, 10);
    const emisorNombre = comp.Emisor?.['@_Nombre'] || 'Proveedor';
    const emisorRfc = comp.Emisor?.['@_Rfc'] || '';
    const moneda = comp['@_Moneda'] || 'MXN';
    const tipoCambio = comp['@_TipoCambio'] ? parseFloat(comp['@_TipoCambio']) : null;
    const serie = comp['@_Serie'] || null;
    const folio = comp['@_Folio'] || null;
    const usoCfdi = comp.Receptor?.['@_UsoCFDI'] || null;

    if (isNaN(total) || isNaN(subtotal)) {
      return { nombreArchivo, error: 'No se pudieron leer Total/SubTotal del XML.' };
    }

    // Traslados: separar IVA (002) de IEPS (003)
    const traslados = comoArreglo(comp.Impuestos?.Traslados?.Traslado);
    let iva = 0;
    let ieps = 0;
    for (const t of traslados) {
      const importe = parseFloat(t['@_Importe']) || 0;
      if (t['@_Impuesto'] === '002') iva += importe;
      else if (t['@_Impuesto'] === '003') ieps += importe;
    }
    // Respaldo si no vino el detalle de Traslados
    if (traslados.length === 0) {
      iva = redondear(total - subtotal);
    }

    const uuid = comp.Complemento?.TimbreFiscalDigital?.['@_UUID'] || null;

    const cuentaAbono = determinarCuentaAbono(metodoPago, formaPago);

    // El Total del CFDI es la fuente de verdad; el neto de inventario se
    // ajusta para garantizar que la póliza cuadre exacto (cubre descuentos
    // y redondeos sin necesidad de una línea aparte).
    const netoInventario = redondear(total - iva - ieps);

    const lineas = [
      { cuenta_codigo: '1104', cuenta_nombre: 'Inventario de alimentos y bebidas', cargo: netoInventario, abono: 0 },
    ];
    if (iva > 0) {
      lineas.push({ cuenta_codigo: '1106', cuenta_nombre: 'IVA acreditable', cargo: redondear(iva), abono: 0 });
    }
    if (ieps > 0) {
      lineas.push({ cuenta_codigo: '1107', cuenta_nombre: 'IEPS acreditable', cargo: redondear(ieps), abono: 0 });
    }
    lineas.push({
      cuenta_codigo: cuentaAbono.codigo,
      cuenta_nombre: cuentaAbono.nombre,
      cargo: 0,
      abono: redondear(total),
    });

    const avisos = [];
    if (cuentaAbono.aviso) avisos.push(cuentaAbono.aviso);
    if (moneda !== 'MXN') {
      avisos.push(
        `Factura en ${moneda}${tipoCambio ? ` (tipo de cambio ${tipoCambio})` : ''}. Los montos de la póliza vienen tal cual del XML — verifica si necesitas convertir a MXN.`
      );
    }

    const conceptos = comoArreglo(comp.Conceptos?.Concepto).map((c) => ({
      claveProdServ: c['@_ClaveProdServ'] || null,
      descripcion: c['@_Descripcion'] || '',
      cantidad: parseFloat(c['@_Cantidad']) || 1,
      claveUnidad: c['@_ClaveUnidad'] || null,
      valorUnitario: parseFloat(c['@_ValorUnitario']) || 0,
      importe: parseFloat(c['@_Importe']) || 0,
    }));

    return {
      nombreArchivo,
      propuesta: {
        fecha,
        concepto: `Compra a ${emisorNombre}`,
        folioFiscal: uuid,
        metodoPago,
        formaPago,
        proveedorNombre: emisorNombre,
        proveedorRfc: emisorRfc,
        usoCfdi,
        moneda,
        tipoCambio,
        serie,
        folio,
        lineas,
        conceptos,
        avisos,
      },
    };
  } catch (error) {
    return { nombreArchivo, error: `No se pudo leer el XML: ${error.message}` };
  }
}

export async function POST(request) {
  try {
    const formData = await request.formData();
    const archivos = formData.getAll('archivos');

    if (!archivos || archivos.length === 0) {
      return NextResponse.json({ error: 'No se recibió ningún archivo.' }, { status: 400 });
    }

    const resultados = [];
    for (const archivo of archivos) {
      const nombreArchivo = archivo.name || 'archivo.xml';
      if (!nombreArchivo.toLowerCase().endsWith('.xml')) {
        resultados.push({ nombreArchivo, error: 'No es un archivo .xml, se omitió.' });
        continue;
      }
      const texto = await archivo.text();
      resultados.push(procesarXml(nombreArchivo, texto));
    }

    return NextResponse.json({ resultados });
  } catch (error) {
    return NextResponse.json({ error: `Error procesando los archivos: ${error.message}` }, { status: 500 });
  }
}
